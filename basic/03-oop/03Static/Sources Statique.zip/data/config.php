<?php
define('JOURS', [
    'Lundi',
    'Mardi',
    'Mercredi',
    'Jeudi',
    'Vendredi',
    'Samedi',
    'Dimanche'
]);

define('CRENEAUX', [
    [
        [8, 12],
        [14, 19]
    ],
    [
        [8, 12],
        [14, 19]
    ],
    [
        [8, 12]
    ],
    [
        [8, 12],
        [14, 19]
    ],
    [
        [8, 12],
        [14, 19]
    ],
    [],
    []
]);