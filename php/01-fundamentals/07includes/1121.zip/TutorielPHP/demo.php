<?php 
require 'separateur.php';
require_once 'functions.php';
require_once 'functions_creneaux.php';

var_dump(repondre_oui_non('Test'));

require 'separateur.php';


require 'separateur.php';
require 'separateur.php';

