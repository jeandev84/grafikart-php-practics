<?php
class UnauthorizedHTTPException extends HTTPException {
    
}