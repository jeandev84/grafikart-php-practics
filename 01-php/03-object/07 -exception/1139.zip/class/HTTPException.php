<?php
class HTTPException extends Exception {
    
}