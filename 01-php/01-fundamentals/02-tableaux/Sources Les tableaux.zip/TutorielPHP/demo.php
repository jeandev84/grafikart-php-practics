<?php
$classe = [
    [
        'nom' => 'Doe',
        'prenom' => 'Jean',
        'notes' => [16, 16, 16]
    ], [
        'nom' => 'Doe',
        'prenom' => 'Jane',
        'notes' => [12, 15, 17]
    ]
];
echo $classe[1]['notes'][1];
