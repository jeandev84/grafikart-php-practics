<?php 
$title = "Nous contacter";
require 'header.php'; 
?>

<h2>Nous contacter</h2>

<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam eveniet similique blanditiis iusto voluptas illo accusantium aperiam quas mollitia! Nobis optio provident tenetur ad ipsam quibusdam impedit voluptatibus doloribus rerum.</p>

<?php require 'footer.php'; ?>